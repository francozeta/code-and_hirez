import { Body, Container, Head, Heading, Html, Img, Link, Preview, Section, Text } from "@react-email/components"

interface ApplicationConfirmationEmailProps {
  applicantName: string
  jobTitle: string
  company: string
  jobSlug?: string // Made optional since we might not have a domain yet
}

export default function ApplicationConfirmationEmail({
  applicantName,
  jobTitle,
  company,
  jobSlug,
}: ApplicationConfirmationEmailProps) {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"

  return (
    <Html>
      <Head />
      <Preview>Tu postulación ha sido recibida - {jobTitle}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Section style={logoSection}>
            <Img
              src={`https://placehold.co/120x40/0070f3/white?text=${encodeURIComponent(company)}`}
              width="120"
              height="40"
              alt={company}
              style={logo}
            />
          </Section>

          <Heading style={h1}>¡Postulación Recibida!</Heading>

          <Text style={text}>Hola {applicantName},</Text>

          <Text style={text}>
            Hemos recibido tu postulación para la posición de <strong>{jobTitle}</strong> en <strong>{company}</strong>.
          </Text>

          <Text style={text}>
            Nuestro equipo revisará tu perfil y nos pondremos en contacto contigo si tu experiencia coincide con lo que
            estamos buscando.
          </Text>

          {baseUrl && jobSlug && (
            <Section style={buttonSection}>
              <Link href={`${baseUrl}/jobs/${jobSlug}`} style={button}>
                Ver Vacante
              </Link>
            </Section>
          )}

          <Text style={footer}>Gracias por tu interés en formar parte de nuestro equipo.</Text>

          <Text style={footerText}>Este es un correo automático, por favor no respondas a este mensaje.</Text>
        </Container>
      </Body>
    </Html>
  )
}

const main = {
  backgroundColor: "#f6f9fc",
  fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Ubuntu,sans-serif',
}

const container = {
  backgroundColor: "#ffffff",
  margin: "0 auto",
  padding: "20px 0 48px",
  marginBottom: "64px",
  maxWidth: "600px",
}

const logoSection = {
  padding: "32px 20px",
  textAlign: "center" as const,
}

const logo = {
  margin: "0 auto",
}

const h1 = {
  color: "#1a1a1a",
  fontSize: "28px",
  fontWeight: "700",
  margin: "40px 0",
  padding: "0 20px",
  textAlign: "center" as const,
}

const text = {
  color: "#525252",
  fontSize: "16px",
  lineHeight: "26px",
  margin: "16px 0",
  padding: "0 20px",
}

const buttonSection = {
  padding: "32px 20px",
  textAlign: "center" as const,
}

const button = {
  backgroundColor: "#0070f3",
  borderRadius: "6px",
  color: "#fff",
  fontSize: "16px",
  fontWeight: "600",
  textDecoration: "none",
  textAlign: "center" as const,
  display: "inline-block",
  padding: "12px 32px",
}

const footer = {
  color: "#525252",
  fontSize: "16px",
  lineHeight: "26px",
  margin: "16px 0",
  padding: "0 20px",
  textAlign: "center" as const,
}

const footerText = {
  color: "#8898aa",
  fontSize: "14px",
  lineHeight: "22px",
  margin: "32px 0 0",
  padding: "0 20px",
  textAlign: "center" as const,
}
